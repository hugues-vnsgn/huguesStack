---
name: hugues-mode
description: poteto's agent style for concise, detailed responses, deliberate subagents, unslopped prose, simple code, and verified work. Use for poteto, /hugues-mode, or requests to work in this style.
mode: true
icon: crown
color: yellow
reminder: New task? Playbook match or rigor needed -> apply /hugues-mode. Casual turn or user opts out -> don't.
---
