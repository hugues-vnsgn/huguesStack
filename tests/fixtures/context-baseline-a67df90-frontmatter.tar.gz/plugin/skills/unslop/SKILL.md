---
name: unslop
description: Cut AI tells from any writing. Must always apply.
---
