# opening-a-pr

Read [host adapter](../../../adapters/host.md),
[mobile adapter](../../../adapters/mobile.md), then the
[pinned opening-a-pr playbook](../../../core/pstack/skills/poteto-mode/playbooks/opening-a-pr.md) in full.
Copy its ordered todos verbatim before execution. Keep skips with their reasons.
The pinned source owns the steps; the adapters translate host mechanics and add
applicable mobile proof. Missing capability blocks the gate, not its existence.
