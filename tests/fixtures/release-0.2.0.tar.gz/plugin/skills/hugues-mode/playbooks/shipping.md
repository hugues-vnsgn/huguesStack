# shipping

Read [host adapter](../../../adapters/host.md),
[mobile adapter](../../../adapters/mobile.md), then the
[pinned shipping playbook](../../../core/pstack/skills/poteto-mode/playbooks/shipping.md) in full.
Copy its ordered todos verbatim before execution. Keep skips with their reasons.
The pinned source owns the steps; the adapters translate host mechanics and add
applicable mobile proof. Missing capability blocks the gate, not its existence.
